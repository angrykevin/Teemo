//
//  ExampleViewController.h
//  Example
//
//  Created by Stefan Arentz on 10-10-05.
//  Copyright 2010 Arentz Consulting. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ExampleViewController : UIViewController {

}

@end

