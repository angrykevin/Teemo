//
//  main.m
//  Example
//
//  Created by Stefan Arentz on 10-10-05.
//  Copyright 2010 Arentz Consulting. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, nil);
    [pool release];
    return retVal;
}
